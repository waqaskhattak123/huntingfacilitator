import React from 'react'
import Calculator from '../components/Calculator'

const CalculatorPg = () => {
  return (
    <div>
      <Calculator/>
    </div>
  )
}

export default CalculatorPg
