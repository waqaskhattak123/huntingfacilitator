import React from 'react'
import ProductDisp from '../components/ProductDisp'

const Productsdis = () => {
  return (
    <div>
      <ProductDisp/>
    </div>
  )
}

export default Productsdis
