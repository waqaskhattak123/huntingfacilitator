import React from 'react'
import LoginComp from '../components/LoginComp'

const Login = () => {
  return (
    <div>
      <LoginComp/>
    </div>
  )
}

export default Login
