import React from 'react'
import UserProfileComp from '../components/UserProfileComp'

const Profile = () => {
  return (
    <div>
      <UserProfileComp/>
    </div>
  )
}

export default Profile
