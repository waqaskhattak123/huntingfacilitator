import React from 'react'
import UpperAboutHeader from '../components/UpperAboutHeader'

const Aboutus = () => {
  return (
    <div>
      <UpperAboutHeader/>
    </div>
  )
}

export default Aboutus
