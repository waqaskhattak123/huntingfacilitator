import React from 'react'
import SignUpComp from '../components/SignUpComp'

const SignUp = () => {
  return (
    <div>
        <SignUpComp/>
      
    </div>
  )
}

export default SignUp
