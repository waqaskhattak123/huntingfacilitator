import React from 'react'
import PrivacyUperHeader from '../components/PrivacyUperHeader'

const Privacy = () => {
  return (
    <div>
        <PrivacyUperHeader/>
      
    </div>
  )
}

export default Privacy
